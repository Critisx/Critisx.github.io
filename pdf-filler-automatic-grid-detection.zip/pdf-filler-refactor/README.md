# PDF Filler — modular refactor

This is a replacement implementation scaffold for the public `Critisx/pdf-filler` app.
It keeps the original browser-only architecture (PDF.js + ONNX Runtime Web + PDF-lib),
but separates document loading, rendering, detection, field state, and export.

## Run locally

Serve this directory over HTTP (service workers and module imports do not work reliably from `file://`):

```bash
python3 -m http.server 8000
```

Open `http://localhost:8000`.

The app loads its libraries and ONNX model from public CDNs/Hugging Face. For production,
pin and self-host those dependencies and the model, verify their hashes, and configure
appropriate CSP headers.

## What changed

- Sequential page processing; no parallel full-page inference.
- Detection canvases are temporary and explicitly released.
- ONNX input/output tensors are disposed in `finally`.
- The detector has no recursive retry path.
- Model input dimensions are validated against model metadata rather than guessed from
  an exception message.
- Existing PDF.js document/page resources are cleaned up.
- Display rendering is capped independently from detector resolution.
- Field data is separated from DOM elements.
- Export has unique field names and handles page rotation via PDF.js viewport transforms.
- Errors are categorized; a failed detection page can be skipped and manually edited.
- Existing AcroForm fields are not intentionally recreated; detected fields are added with
  unique names. Review existing fields before using this as a production form editor.

## Important model compatibility note

The original repository assumes the FFDNet-S output layout and class order. This refactor
retains the original decoder shape and the assumed classes `text`, `check`, `signature`,
but those assumptions MUST be verified against the exact ONNX model version and a labeled
test corpus. If output metadata/layout differs, update `src/detection/decoder.js`.
The code does not claim that class IDs or output coordinates are verified.

The detector input size is read from the model metadata when statically available. Dynamic
or symbolic dimensions fall back to 1216, matching the original implementation. Do not
change this value without validating model preprocessing and accuracy.

## Current scope / limitations

- Signature detections are represented as editable text fields labelled “Signature”.
  A true handwritten signature pad and image embedding are not included in this first
  replacement scaffold.
- Existing AcroForm fields are preserved by loading the original PDF, but automatic
  deduplication against existing widgets is not yet implemented.
- Rotated-page export uses PDF.js viewport conversion and must be regression-tested with
  the PDFs you support.
- The model download is cached in Cache Storage; production deployments should add a
  pinned SHA-256 checksum and a versioned model URL.
- Memory usage still depends on browser/device limits and ONNX Runtime internals.

## Suggested regression set

Test: 1-page, 10-page, 50-page, scanned, encrypted, landscape, 90/180/270-degree rotated,
non-zero crop box, existing AcroForm, checkbox-heavy, and large image-based PDFs.
Test on iPhone Safari as well as desktop Chromium/Firefox.


## Character-box fields (new)

The manual field tool now includes **Character boxes**. Choose the field type, set the
number of character cells, click the row on the PDF, and type. The field limits input
to the selected count and uppercases it. On export, each character is drawn separately
and centered within its cell. This is designed for forms such as the supplied Trinidad
and Tobago BIR IA-001, where names, dates, ID numbers, and phone numbers use ruled cells.

This is a manual placement tool, not automatic character-cell recognition. For divided
sections (for example home/work/cell telephone numbers), place one character-box field
per section and set the count for each section. Checkboxes remain separate fields.
The supplied IA-001 page has 19 numbered applicant entries, but not all are character
rows; addresses and long descriptions are better entered as ordinary text fields.

Before relying on exported forms, compare the result visually with the original PDF.
Font sizing and exact cell alignment may need per-document adjustment.


## Automatic character-grid detection update

A second, model-independent detector now analyses the rendered page for long horizontal
rules and repeated vertical dividers. It proposes character-box fields for ruled rows,
including forms like BIR IA-001. AI detections are still attempted first; grid detections
are merged when they do not overlap an AI result. If the AI model cannot load, grid
analysis still runs. Retry now reprocesses failed pages and replaces their prior preview
instead of adding duplicate page canvases.

This is heuristic computer vision, not a guaranteed form parser. It may miss faint,
broken, skewed, or low-resolution rules and may mistake table rows for character rows.
Review every proposed field before export. Addresses and long free-text spaces still
need normal text fields. The grid detector is intentionally conservative.
