export const CONFIG = {
  modelUrl: "https://huggingface.co/jbarrow/FFDNet-S-cpu/resolve/main/FFDNet-S.onnx",
  modelCache: "pdf-filler-model-v2",
  modelCacheKey: "ffdnet-s-model",
  ortBaseUrl: "https://cdn.jsdelivr.net/npm/onnxruntime-web@1.20.1/dist/",
  pdfWorkerUrl: "https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js",
  confidence: 0.30,
  enableAiDetection: false,
  fallbackInputSize: 1216,
  mobileMaxDisplayDimension: 1500,
  desktopMaxDisplayDimension: 2200,
  maxDetectionConcurrency: 1
};
