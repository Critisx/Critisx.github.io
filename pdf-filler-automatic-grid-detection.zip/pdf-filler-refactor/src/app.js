import { CONFIG } from "./config.js";
import { createStatus } from "./ui/status.js";
import { DocumentManager } from "./pdf/document-manager.js";
import { renderPage } from "./pdf/renderer.js";
import { ModelManager } from "./detection/model.js";
import { Detector } from "./detection/detector.js";
import { detectCharacterRows } from "./detection/grid-detector.js";
import { FieldStore } from "./fields/store.js";
import { FieldView } from "./fields/view.js";
import { exportPdf } from "./pdf/exporter.js";
import { userMessage } from "./errors.js";

pdfjsLib.GlobalWorkerOptions.workerSrc = CONFIG.pdfWorkerUrl;

const $ = selector => document.querySelector(selector);
const status = createStatus();
const documentManager = new DocumentManager();
const modelManager = new ModelManager(status);
const detector = new Detector(modelManager);
const store = new FieldStore();
let pages = [];
let editing = false;
let failedPages = [];
let busy = false;

const fieldView = () => new FieldView(store, pages, () => editing);
const setControls = enabled => {
  $("#edit").disabled = !enabled;
  $("#save").disabled = !enabled;
  $("#manual").disabled = !enabled;
  $("#field-type").disabled = !enabled;
  $("#char-count").disabled = !enabled;
  $("#retry").disabled = failedPages.length === 0 || busy;
};
function clearCurrent() {
  store.clear();
  pages = [];
  failedPages = [];
  $("#pages").replaceChildren();
  $("#edit").disabled = $("#save").disabled = $("#manual").disabled = $("#retry").disabled = true;
  $("#field-type").disabled = $("#char-count").disabled = true;
}
async function processPage(pageIndex, page, total) {
  // A retry replaces the old page preview instead of stacking duplicate canvases.
  const previous = pages[pageIndex];
  if (previous?.container) previous.container.remove();
  for (const field of [...store.forPage(pageIndex)]) store.remove(field);

  status.set(`Rendering page ${pageIndex + 1} of ${total}…`, pageIndex / total);
  const container = document.createElement("section");
  container.className = "page";
  $("#pages").append(container);
  const rendered = await renderPage(page, container);
  const info = { container, width: rendered.baseWidth, height: rendered.baseHeight,
    viewport: page.getViewport({ scale: 1 }) };
  pages[pageIndex] = info;
  container.addEventListener("click", event => {
    if (!editing || event.target !== rendered.canvas) return;
    const rect = rendered.canvas.getBoundingClientRect();
    const factor = info.width / rect.width;
    const type = $("#field-type").value;
    const charCount = Math.max(1, Math.min(60, Number($("#char-count").value) || 12));
    const width = type === "charbox" ? Math.max(120, charCount * 18) : 120;
    fieldView().mount(pageIndex, {
      x: Math.max(0, (event.clientX - rect.left) * factor - width / 2),
      y: Math.max(0, (event.clientY - rect.top) * factor - 10),
      w: width, h: type === "check" ? 16 : 20, type, charCount, source: "manual"
    });
  });

  let aiDetections = [];
  if (CONFIG.enableAiDetection) {
    try {
      status.set(`AI detection: page ${pageIndex + 1} of ${total}…`, (pageIndex + 0.5) / total);
      aiDetections = await detector.detect(page);
    } catch (error) {
      console.warn(`AI detection unavailable on page ${pageIndex + 1}; using grid analysis.`, error);
    }
  }

  // The image-based pass is independent of the ONNX model and targets printed
  // character-cell rows (like the supplied BIR IA-001).
  let gridDetections = [];
  try {
    gridDetections = detectCharacterRows(rendered.canvas, info.width, info.height);
  } catch (error) {
    console.warn(`Grid analysis failed on page ${pageIndex + 1}.`, error);
  }

  const combined = [...aiDetections];
  for (const grid of gridDetections) {
    const duplicate = combined.some(item =>
      Math.abs(item.x - grid.x) < 10 && Math.abs(item.y - grid.y) < 8 &&
      Math.abs(item.w - grid.w) < 20
    );
    if (!duplicate) combined.push(grid);
  }
  for (const detection of combined) fieldView().mount(pageIndex, detection);
  if (!combined.length) console.info(`No fields detected on page ${pageIndex + 1}.`);
  try { page.cleanup(); } catch {}
}

async function openFile(file) {
  if (busy) return;
  busy = true;
  clearCurrent();
  $("#pick").hidden = true;
  try {
    const pdf = await documentManager.open(file);
    // Model failure should not block manual PDF filling.
    for (let index = 0; index < pdf.numPages; index++) {
      try {
        const page = await pdf.getPage(index + 1);
        await processPage(index, page, pdf.numPages);
      } catch (error) {
        console.error(`Page ${index + 1} could not be processed`, error);
        failedPages.push(index);
      }
    }
    const gridCount = store.items.filter(field => field.source === "grid").length;
    status.set(`${store.items.length} fields proposed (${gridCount} character-grid rows). Review the boxes; adjust or add fields where needed.${failedPages.length ? ` ${failedPages.length} page(s) failed to render and can be retried.` : ""}`);
    setControls(true);
  } catch (error) {
    console.error(error);
    status.set(userMessage(error));
    $("#pick").hidden = false;
  } finally {
    busy = false;
    $("#retry").disabled = failedPages.length === 0;
  }
}

$("#file").addEventListener("change", event => {
  const file = event.target.files?.[0];
  if (file) openFile(file);
  event.target.value = "";
});
$("#edit").addEventListener("click", () => {
  editing = !editing;
  $("#edit").textContent = editing ? "Done editing" : "Edit boxes";
  $("#edit").classList.toggle("on", editing);
  $("#pages").classList.toggle("editing", editing);
  $("#hint").hidden = !editing;
});
$("#manual").addEventListener("click", () => {
  if (!pages.length) return;
  editing = true;
  $("#edit").textContent = "Done editing";
  $("#pages").classList.add("editing");
  $("#hint").hidden = false;
  const type = $("#field-type").value;
  const charCount = Math.max(1, Math.min(60, Number($("#char-count").value) || 12));
  fieldView().mount(0, {
    x: 40, y: 40, w: type === "charbox" ? Math.max(120, charCount * 18) : 160,
    h: type === "check" ? 16 : 24, type, charCount, source: "manual"
  });
});
$("#retry").addEventListener("click", async () => {
  if (busy || !failedPages.length) return;
  busy = true;
  const retry = [...new Set(failedPages)];
  failedPages = [];
  $("#retry").disabled = true;
  try {
    for (const index of retry) {
      try {
        const page = await documentManager.pdf.getPage(index + 1);
        await processPage(index, page, documentManager.pdf.numPages);
      } catch (error) {
        console.error(`Retry failed on page ${index + 1}`, error);
        failedPages.push(index);
      }
    }
    status.set(`Retry complete. ${failedPages.length} page(s) still need attention.`);
  } finally {
    busy = false;
    $("#retry").disabled = failedPages.length === 0;
  }
});

$("#save").addEventListener("click", async () => {
  if (busy || !documentManager.bytes) return;
  busy = true;
  $("#save").disabled = true;
  try {
    status.set("Building your PDF…");
    const file = await exportPdf(documentManager.originalBytes, store.items, pages, documentManager.fileName);
    if (navigator.canShare?.({ files: [file] })) {
      try { await navigator.share({ files: [file], title: file.name }); status.set("Share sheet opened."); }
      catch (error) {
        if (error.name === "AbortError") status.set("Sharing cancelled. Your edits are still here.");
        else throw error;
      }
    } else {
      const url = URL.createObjectURL(file);
      const anchor = document.createElement("a");
      anchor.href = url; anchor.download = file.name; anchor.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      status.set("PDF download started.");
    }
  } catch (error) {
    console.error(error);
    status.set(`Could not export: ${userMessage(error)}`);
  } finally {
    busy = false;
    $("#save").disabled = false;
  }
});

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("./sw.js").catch(error => console.warn("Service worker unavailable", error));
}
