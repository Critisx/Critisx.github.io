// Image-based detector for ruled character-cell rows.
// It does not need the ONNX model: it analyses the rendered PDF page.
export function detectCharacterRows(canvas, baseWidth, baseHeight) {
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  const { width, height } = canvas;
  if (!width || !height) return [];
  const image = ctx.getImageData(0, 0, width, height);
  const data = image.data;
  const dark = (x, y) => {
    const i = (y * width + x) * 4;
    return data[i] < 105 && data[i + 1] < 105 && data[i + 2] < 105;
  };

  // Find horizontal rules that span a meaningful part of the page.
  const horizontal = [];
  const minRun = Math.max(80, Math.floor(width * 0.12));
  for (let y = 0; y < height; y++) {
    let longest = 0, run = 0;
    for (let x = 0; x < width; x++) {
      if (dark(x, y)) { run++; longest = Math.max(longest, run); }
      else run = 0;
    }
    if (longest >= minRun) horizontal.push(y);
  }
  const rules = [];
  for (const y of horizontal) {
    const last = rules[rules.length - 1];
    if (last && y - last.end <= 2) last.end = y;
    else rules.push({ start: y, end: y });
  }
  const bands = [];
  for (let i = 0; i < rules.length - 1; i++) {
    const top = rules[i].end, bottom = rules[i + 1].start;
    const bandH = bottom - top;
    if (bandH < 9 || bandH > 34) continue;

    // Count vertical ink per column within the band.
    const columns = [];
    const required = Math.max(4, Math.floor(bandH * 0.42));
    for (let x = 0; x < width; x++) {
      let count = 0;
      for (let y = top + 2; y < bottom - 1; y++) if (dark(x, y)) count++;
      if (count >= required) columns.push(x);
    }
    const groups = [];
    for (const x of columns) {
      const last = groups[groups.length - 1];
      if (last && x - last.end <= 3) last.end = x;
      else groups.push({ start: x, end: x });
    }
    const lines = groups.filter(g => g.end - g.start <= 5);
    if (lines.length < 7) continue;
    const left = lines[0].start, right = lines[lines.length - 1].end;
    const span = right - left;
    if (span < width * 0.18) continue;
    const count = lines.length - 1;
    if (count < 6 || count > 60) continue;
    bands.push({
      x: left * baseWidth / width,
      y: (top + 1) * baseHeight / height,
      w: span * baseWidth / width,
      h: Math.max(8, (bandH - 2) * baseHeight / height),
      type: "charbox",
      charCount: count,
      source: "grid"
    });
  }

  // Remove near-duplicate bands caused by thick/double printed rules.
  bands.sort((a, b) => a.y - b.y);
  return bands.filter((item, index) =>
    !bands.slice(0, index).some(prev =>
      Math.abs(prev.y - item.y) < 4 && Math.abs(prev.x - item.x) < 12
    )
  );
}
