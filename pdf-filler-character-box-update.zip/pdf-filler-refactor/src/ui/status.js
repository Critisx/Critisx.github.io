export function createStatus() {
  const status = document.querySelector("#status");
  const bar = document.querySelector("#bar");
  const fill = bar.querySelector("i");
  return {
    set(message, progress = null) {
      status.textContent = message;
      bar.hidden = progress == null;
      if (progress != null) fill.style.width = `${Math.max(0, Math.min(1, progress)) * 100}%`;
    }
  };
}
