let nextId = 1;
export class FieldStore {
  constructor() { this.items = []; }
  add(pageIndex, field) {
    const item = {
      id: `field-${nextId++}`, pageIndex, type: field.type || "text",
      x: field.x, y: field.y, w: field.w, h: field.h,
      value: field.value ?? "", charCount: field.charCount ?? 12, confidence: field.confidence ?? null,
      source: field.source || "manual", element: null
    };
    this.items.push(item);
    return item;
  }
  remove(item) { this.items = this.items.filter(field => field.id !== item.id); item.element?.remove(); }
  forPage(index) { return this.items.filter(item => item.pageIndex === index); }
  clear() { for (const item of this.items) item.element?.remove(); this.items = []; nextId = 1; }
}
