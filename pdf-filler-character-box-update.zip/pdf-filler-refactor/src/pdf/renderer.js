export function displayScale(viewport) {
  const mobile = matchMedia("(max-width: 700px)").matches;
  const dpr = mobile ? 1 : Math.min(devicePixelRatio || 1, 1.5);
  const cap = mobile ? 1500 : 2200;
  return Math.min(dpr * 1.25, cap / Math.max(viewport.width, viewport.height));
}

export async function renderPage(page, container) {
  const base = page.getViewport({ scale: 1 });
  const scale = displayScale(base);
  const viewport = page.getViewport({ scale });
  const canvas = document.createElement("canvas");
  canvas.width = Math.ceil(viewport.width);
  canvas.height = Math.ceil(viewport.height);
  container.append(canvas);
  const task = page.render({ canvasContext: canvas.getContext("2d", { alpha: false }), viewport });
  await task.promise;
  return { canvas, baseWidth: base.width, baseHeight: base.height, viewport };
}
