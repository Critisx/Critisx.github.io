import { AppError } from "../errors.js";

export class DocumentManager {
  constructor() { this.pdf = null; this.bytes = null; this.fileName = "filled.pdf"; }
  async open(file) {
    await this.close();
    if (!file || file.type !== "application/pdf") throw new AppError("INVALID_PDF", "Please choose a PDF file.");
    this.fileName = file.name.replace(/\.pdf$/i, "") + "-filled.pdf";
    this.bytes = new Uint8Array(await file.arrayBuffer());
    try {
      this.pdf = await pdfjsLib.getDocument({ data: this.bytes.slice() }).promise;
      return this.pdf;
    } catch (error) {
      this.bytes = null;
      throw new AppError("INVALID_PDF", "PDF.js could not open this document.", error);
    }
  }
  async close() {
    if (this.pdf) {
      try { await this.pdf.cleanup(); } catch {}
      try { await this.pdf.destroy(); } catch {}
    }
    this.pdf = null;
    this.bytes = null;
  }
  get originalBytes() {
    if (!this.bytes) throw new Error("No PDF is loaded.");
    return this.bytes;
  }
}
