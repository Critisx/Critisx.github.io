function uniqueFieldName(form, base) {
  let name = base, suffix = 1;
  while (form.getFieldMaybe(name)) name = `${base}-${suffix++}`;
  return name;
}

export async function exportPdf(originalBytes, fields, pages, fileName) {
  const { PDFDocument, StandardFonts } = PDFLib;
  const pdf = await PDFDocument.load(originalBytes, { ignoreEncryption: false });
  const form = pdf.getForm();
  const pdfPages = pdf.getPages();
  const font = await pdf.embedFont(StandardFonts.Helvetica);

  for (const field of fields) {
    const pdfPage = pdfPages[field.pageIndex];
    const pageInfo = pages[field.pageIndex];
    if (!pdfPage || !pageInfo) continue;

    // PDF.js viewport transform maps PDF coordinates to CSS/display coordinates,
    // including page rotation. Invert it to map field top-left coordinates back.
    const viewport = pageInfo.viewport;
    const p1 = viewport.convertToPdfPoint(field.x, field.y);
    const p2 = viewport.convertToPdfPoint(field.x + field.w, field.y + field.h);
    const x = Math.min(p1[0], p2[0]);
    const y = Math.min(p1[1], p2[1]);
    const width = Math.abs(p2[0] - p1[0]);
    const height = Math.abs(p2[1] - p1[1]);
    const options = { x, y, width, height, borderWidth: 0 };

    const name = uniqueFieldName(form, field.id);
    if (field.type === "charbox") {
      // Draw one glyph per cell instead of creating a conventional text field.
      // This matches printed character-cell forms such as the supplied BIR IA-001.
      const chars = Array.from(String(field.value || "").toUpperCase()).slice(0, field.charCount || 12);
      const count = Math.max(1, field.charCount || 12);
      const cellWidth = width / count;
      const fontSize = Math.max(5, Math.min(height * 0.78, 12));
      chars.forEach((char, index) => {
        if (!char || char === " ") return;
        const textWidth = font.widthOfTextAtSize(char, fontSize);
        pdfPage.drawText(char, {
          x: x + index * cellWidth + Math.max(0, (cellWidth - textWidth) / 2),
          y: y + Math.max(0, (height - fontSize) / 2),
          size: fontSize, font
        });
      });
      continue;
    }
    if (field.type === "check") {
      const checkbox = form.createCheckBox(name);
      checkbox.addToPage(pdfPage, options);
      if (field.value === "1") checkbox.check();
    } else {
      const text = form.createTextField(name);
      text.addToPage(pdfPage, { ...options, font });
      if (field.value) text.setText(String(field.value));
      if (field.type === "signature") text.setTooltip("Signature field — typed placeholder, not a cryptographic signature.");
    }
  }
  form.updateFieldAppearances(font);
  const bytes = await pdf.save();
  return new File([bytes], fileName, { type: "application/pdf" });
}
