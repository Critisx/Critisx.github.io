import { CONFIG } from "./config.js";
import { createStatus } from "./ui/status.js";
import { DocumentManager } from "./pdf/document-manager.js";
import { renderPage } from "./pdf/renderer.js";
import { ModelManager } from "./detection/model.js";
import { Detector } from "./detection/detector.js";
import { FieldStore } from "./fields/store.js";
import { FieldView } from "./fields/view.js";
import { exportPdf } from "./pdf/exporter.js";
import { userMessage } from "./errors.js";

pdfjsLib.GlobalWorkerOptions.workerSrc = CONFIG.pdfWorkerUrl;

const $ = selector => document.querySelector(selector);
const status = createStatus();
const documentManager = new DocumentManager();
const modelManager = new ModelManager(status);
const detector = new Detector(modelManager);
const store = new FieldStore();
let pages = [];
let editing = false;
let failedPages = [];
let busy = false;

const fieldView = () => new FieldView(store, pages, () => editing);
const setControls = enabled => {
  $("#edit").disabled = !enabled;
  $("#save").disabled = !enabled;
  $("#manual").disabled = !enabled;\n  $("#field-type").disabled = !enabled;\n  $("#char-count").disabled = !enabled;
  $("#retry").disabled = failedPages.length === 0 || busy;
};
function clearCurrent() {
  store.clear();
  pages = [];
  failedPages = [];
  $("#pages").replaceChildren();
  $("#edit").disabled = $("#save").disabled = $("#manual").disabled = $("#retry").disabled = true;
  $("#field-type").disabled = $("#char-count").disabled = true;
}
async function processPage(pageIndex, page, total) {
  status.set(`Rendering page ${pageIndex + 1} of ${total}…`, pageIndex / total);
  const container = document.createElement("section");
  container.className = "page";
  $("#pages").append(container);
  const rendered = await renderPage(page, container);
  const info = { container, width: rendered.baseWidth, height: rendered.baseHeight, viewport: page.getViewport({ scale: 1 }) };
  pages[pageIndex] = info;
  container.addEventListener("click", event => {
    if (!editing || event.target !== rendered.canvas) return;
    const rect = rendered.canvas.getBoundingClientRect();
    const factor = info.width / rect.width;
    const type = $("#field-type").value;
    const charCount = Math.max(1, Math.min(60, Number($("#char-count").value) || 12));
    const width = type === "charbox" ? Math.max(120, charCount * 18) : 120;
    fieldView().mount(pageIndex, {
      x: Math.max(0, (event.clientX - rect.left) * factor - width / 2),
      y: Math.max(0, (event.clientY - rect.top) * factor - 10),
      w: width, h: type === "check" ? 16 : 20, type, charCount, source: "manual"
    });
  });
  status.set(`Detecting fields on page ${pageIndex + 1} of ${total}…`, (pageIndex + 0.5) / total);
  try {
    const detections = await detector.detect(page);
    const view = fieldView();
    for (const detection of detections) view.mount(pageIndex, detection);
  } catch (error) {
    console.error(`Detection failed on page ${pageIndex + 1}`, error);
    failedPages.push(pageIndex);
  } finally {
    try { page.cleanup(); } catch {}
  }
}

async function openFile(file) {
  if (busy) return;
  busy = true;
  clearCurrent();
  $("#pick").hidden = true;
  try {
    const pdf = await documentManager.open(file);
    // Model failure should not block manual PDF filling.
    try { await modelManager.load(); }
    catch (error) { console.warn("Detector unavailable; continuing in manual mode.", error); }
    for (let index = 0; index < pdf.numPages; index++) {
      const page = await pdf.getPage(index + 1);
      await processPage(index, page, pdf.numPages);
    }
    status.set(`${store.items.length} fields found. ${failedPages.length ? `${failedPages.length} page(s) need manual detection retry.` : "Review and fill the fields."}`);
    setControls(true);
  } catch (error) {
    console.error(error);
    status.set(userMessage(error));
    $("#pick").hidden = false;
  } finally {
    busy = false;
    $("#retry").disabled = failedPages.length === 0;
  }
}

$("#file").addEventListener("change", event => {
  const file = event.target.files?.[0];
  if (file) openFile(file);
  event.target.value = "";
});
$("#edit").addEventListener("click", () => {
  editing = !editing;
  $("#edit").textContent = editing ? "Done editing" : "Edit boxes";
  $("#edit").classList.toggle("on", editing);
  $("#pages").classList.toggle("editing", editing);
  $("#hint").hidden = !editing;
});
$("#manual").addEventListener("click", () => {
  if (!pages.length) return;
  editing = true;
  $("#edit").textContent = "Done editing";
  $("#pages").classList.add("editing");
  $("#hint").hidden = false;
  const type = $("#field-type").value;
  const charCount = Math.max(1, Math.min(60, Number($("#char-count").value) || 12));
  fieldView().mount(0, {
    x: 40, y: 40, w: type === "charbox" ? Math.max(120, charCount * 18) : 160,
    h: type === "check" ? 16 : 24, type, charCount, source: "manual"
  });
});
$("#retry").addEventListener("click", async () => {
  if (busy || !failedPages.length) return;
  busy = true;
  const retry = [...failedPages];
  failedPages = [];
  try {
    await modelManager.load();
    for (const index of retry) {
      const page = await documentManager.pdf.getPage(index + 1);
      await processPage(index, page, documentManager.pdf.numPages);
    }
    status.set(`Retry complete. ${failedPages.length} page(s) still need manual review.`);
  } catch (error) {
    status.set(userMessage(error));
  } finally {
    busy = false;
    $("#retry").disabled = failedPages.length === 0;
  }
});
$("#save").addEventListener("click", async () => {
  if (busy || !documentManager.bytes) return;
  busy = true;
  $("#save").disabled = true;
  try {
    status.set("Building your PDF…");
    const file = await exportPdf(documentManager.originalBytes, store.items, pages, documentManager.fileName);
    if (navigator.canShare?.({ files: [file] })) {
      try { await navigator.share({ files: [file], title: file.name }); status.set("Share sheet opened."); }
      catch (error) {
        if (error.name === "AbortError") status.set("Sharing cancelled. Your edits are still here.");
        else throw error;
      }
    } else {
      const url = URL.createObjectURL(file);
      const anchor = document.createElement("a");
      anchor.href = url; anchor.download = file.name; anchor.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      status.set("PDF download started.");
    }
  } catch (error) {
    console.error(error);
    status.set(`Could not export: ${userMessage(error)}`);
  } finally {
    busy = false;
    $("#save").disabled = false;
  }
});

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("./sw.js").catch(error => console.warn("Service worker unavailable", error));
}
