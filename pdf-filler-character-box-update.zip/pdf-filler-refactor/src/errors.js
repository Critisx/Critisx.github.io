export class AppError extends Error {
  constructor(code, message, cause) {
    super(message, { cause });
    this.name = "AppError";
    this.code = code;
  }
}
export function classifyError(error) {
  const message = String(error?.message ?? error ?? "");
  if (/memory|allocation|out of memory|oom/i.test(message)) return "MEMORY";
  if (/password|encrypted/i.test(message)) return "ENCRYPTED_PDF";
  if (/invalid pdf|format|missing.*pdf/i.test(message)) return "INVALID_PDF";
  if (/fetch|network|load failed/i.test(message)) return "NETWORK";
  return "UNKNOWN";
}
export function userMessage(error) {
  switch (classifyError(error)) {
    case "MEMORY": return "The device ran low on available memory. The current page was stopped; try a smaller PDF or close other tabs.";
    case "ENCRYPTED_PDF": return "This PDF is encrypted or password-protected. Password handling is not implemented in this build.";
    case "INVALID_PDF": return "This file could not be read as a valid PDF.";
    case "NETWORK": return "A required library or detection model could not be downloaded. Check your connection and retry.";
    default: return `Something went wrong: ${error?.message || String(error)}`;
  }
}
