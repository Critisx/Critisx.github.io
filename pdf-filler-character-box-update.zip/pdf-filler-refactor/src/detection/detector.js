import { CONFIG } from "../config.js";
import { decode } from "./decoder.js";

const CLASS_NAMES = ["text", "check", "signature"];

export class Detector {
  constructor(modelManager) { this.modelManager = modelManager; }
  async detect(page) {
    const session = await this.modelManager.load();
    const size = this.modelManager.inputSize;
    const base = page.getViewport({ scale: 1 });
    const scale = size / Math.max(base.width, base.height);
    const width = Math.max(1, Math.round(base.width * scale));
    const height = Math.max(1, Math.round(base.height * scale));
    const offsetX = Math.floor((size - width) / 2);
    const offsetY = Math.floor((size - height) / 2);
    const inputCanvas = document.createElement("canvas");
    const pageCanvas = document.createElement("canvas");
    inputCanvas.width = size; inputCanvas.height = size;
    pageCanvas.width = width; pageCanvas.height = height;
    let renderTask;
    try {
      const ctx = inputCanvas.getContext("2d", { willReadFrequently: true, alpha: false });
      const pageCtx = pageCanvas.getContext("2d", { alpha: false });
      ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, size, size);
      renderTask = page.render({ canvasContext: pageCtx, viewport: page.getViewport({ scale }) });
      await renderTask.promise;
      ctx.drawImage(pageCanvas, offsetX, offsetY);
      const pixels = ctx.getImageData(0, 0, size, size).data;
      const n = size * size;
      const inputData = new Float32Array(3 * n);
      for (let i = 0; i < n; i++) {
        inputData[i] = pixels[i * 4] / 255;
        inputData[n + i] = pixels[i * 4 + 1] / 255;
        inputData[2 * n + i] = pixels[i * 4 + 2] / 255;
      }
      const inputTensor = new ort.Tensor("float32", inputData, [1, 3, size, size]);
      let outputs;
      try {
        outputs = await session.run({ [session.inputNames[0]]: inputTensor });
        return decode(outputs, session).map(box => ({
          x: (box.x1 - offsetX) / scale,
          y: (box.y1 - offsetY) / scale,
          w: (box.x2 - box.x1) / scale,
          h: (box.y2 - box.y1) / scale,
          type: CLASS_NAMES[box.classId] || "text",
          confidence: box.score,
          source: "ai"
        })).filter(box => box.w > 4 && box.h > 4);
      } finally {
        inputTensor.dispose();
        if (outputs) for (const tensor of Object.values(outputs)) tensor?.dispose?.();
      }
    } finally {
      try { renderTask?.cancel?.(); } catch {}
      inputCanvas.width = inputCanvas.height = 0;
      pageCanvas.width = pageCanvas.height = 0;
    }
  }
}
