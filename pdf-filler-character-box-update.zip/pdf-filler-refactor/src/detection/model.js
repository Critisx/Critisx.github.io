import { CONFIG } from "../config.js";

export class ModelManager {
  constructor(status) { this.status = status; this.session = null; this.inputSize = CONFIG.fallbackInputSize; }
  async load() {
    if (this.session) return this.session;
    ort.env.wasm.wasmPaths = CONFIG.ortBaseUrl;
    ort.env.wasm.numThreads = 1;
    const bytes = await this.#getModelBytes();
    this.status.set("Starting detector…");
    this.session = await ort.InferenceSession.create(bytes, {
      executionProviders: ["wasm"],
      graphOptimizationLevel: "basic",
      enableCpuMemArena: false,
      enableMemPattern: false
    });
    const meta = this.session.inputMetadata?.[0];
    const dims = meta?.dimensions || meta?.dims;
    const fixed = Array.isArray(dims) ? dims.filter(Number.isInteger) : [];
    const spatial = fixed.slice(-2);
    if (spatial.length === 2 && spatial[0] === spatial[1] && spatial[0] > 0) this.inputSize = spatial[0];
    return this.session;
  }
  async #getModelBytes() {
    const cache = await caches.open(CONFIG.modelCache);
    let response = await cache.match(CONFIG.modelCacheKey);
    if (!response) {
      this.status.set("Downloading detection model…");
      const network = await fetch(CONFIG.modelUrl);
      if (!network.ok) throw new Error(`Model download failed (${network.status}).`);
      // Cache the response clone without building an additional Blob from chunks.
      await cache.put(CONFIG.modelCacheKey, network.clone());
      response = network;
    }
    return response.arrayBuffer();
  }
  async dispose() {
    if (this.session) {
      try { await this.session.release(); } catch {}
      this.session = null;
    }
  }
}
