import { CONFIG } from "../config.js";

function iou(a, b) {
  const x1 = Math.max(a.x1, b.x1), y1 = Math.max(a.y1, b.y1);
  const x2 = Math.min(a.x2, b.x2), y2 = Math.min(a.y2, b.y2);
  const intersection = Math.max(0, x2 - x1) * Math.max(0, y2 - y1);
  const areaA = Math.max(0, a.x2 - a.x1) * Math.max(0, a.y2 - a.y1);
  const areaB = Math.max(0, b.x2 - b.x1) * Math.max(0, b.y2 - b.y1);
  return intersection / (areaA + areaB - intersection + 1e-6);
}

// Retains the original repository's two supported output layouts.
// Verify this decoder and class order against the exact model before production.
export function decode(output, session) {
  const tensor = output[session.outputNames[0]];
  if (!tensor?.dims || !tensor?.data) throw new Error("Detector returned an unsupported output tensor.");
  const dims = tensor.dims, data = tensor.data, candidates = [];
  if (dims.length === 3 && dims[2] === 6) {
    for (let i = 0; i < dims[1]; i++) {
      const o = i * 6;
      if (data[o + 4] >= CONFIG.confidence) candidates.push({
        x1: data[o], y1: data[o + 1], x2: data[o + 2], y2: data[o + 3],
        score: data[o + 4], classId: Math.round(data[o + 5])
      });
    }
  } else if (dims.length === 3) {
    const count = dims[2], classCount = dims[1] - 4;
    for (let i = 0; i < count; i++) {
      let classId = 0, score = 0;
      for (let k = 0; k < classCount; k++) {
        const value = data[(4 + k) * count + i];
        if (value > score) { score = value; classId = k; }
      }
      if (score < CONFIG.confidence) continue;
      const cx = data[i], cy = data[count + i], w = data[2 * count + i], h = data[3 * count + i];
      candidates.push({ x1: cx - w / 2, y1: cy - h / 2, x2: cx + w / 2, y2: cy + h / 2, score, classId });
    }
  } else {
    throw new Error(`Unsupported detector output dimensions: ${dims.join("x")}`);
  }
  candidates.sort((a, b) => b.score - a.score);
  const kept = [];
  for (const candidate of candidates) if (!kept.some(item => iou(item, candidate) > 0.5)) kept.push(candidate);
  return kept;
}
