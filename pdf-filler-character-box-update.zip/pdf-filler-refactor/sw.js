const CACHE = "pdf-filler-shell-v2";
const SHELL = [
  "./", "./index.html", "./styles.css", "./src/app.js", "./src/config.js",
  "./src/errors.js", "./src/ui/status.js", "./src/pdf/document-manager.js",
  "./src/pdf/renderer.js", "./src/pdf/exporter.js", "./src/detection/model.js",
  "./src/detection/decoder.js", "./src/detection/detector.js",
  "./src/fields/store.js", "./src/fields/view.js"
];
self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL)));
  self.skipWaiting();
});
self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) if (key !== CACHE && key.startsWith("pdf-filler-shell-")) await caches.delete(key);
    await self.clients.claim();
  })());
});
self.addEventListener("fetch", event => {
  const url = new URL(event.request.url);
  if (event.request.method !== "GET" || url.origin !== self.location.origin) return;
  event.respondWith((async () => {
    const cached = await caches.match(event.request);
    if (cached) return cached;
    const response = await fetch(event.request);
    if (response.ok && event.request.destination !== "document") {
      const cache = await caches.open(CACHE);
      cache.put(event.request, response.clone()).catch(() => {});
    }
    return response;
  })());
});
