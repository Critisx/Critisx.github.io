export class FieldView {
  constructor(store, pages, isEditing) { this.store = store; this.pages = pages; this.isEditing = isEditing; }
  mount(pageIndex, definition) {
    const field = this.store.add(pageIndex, definition);
    const page = this.pages[pageIndex];
    const element = document.createElement("input");
    element.className = "field";
    if (field.type === "check") {
      element.type = "checkbox"; element.checked = field.value === "1" || field.value === true;
      element.addEventListener("change", () => field.value = element.checked ? "1" : "");
    } else {
      element.type = "text";
      element.placeholder = field.type === "signature" ? "Signature (type name)" : "";
      element.autocomplete = "off";
      element.value = String(field.value);
      element.addEventListener("input", () => field.value = element.value);
    }
    element.addEventListener("pointerdown", event => {
      if (this.isEditing()) { event.preventDefault(); this.store.remove(field); }
    });
    page.container.append(element);
    field.element = element;
    this.place(field);
    return field;
  }
  place(field) {
    const page = this.pages[field.pageIndex], element = field.element;
    element.style.left = `${field.x / page.width * 100}%`;
    element.style.top = `${(field.y + field.h / 2) / page.height * 100}%`;
    element.style.width = `${Math.max(1, field.w / page.width * 100)}%`;
    element.style.height = field.type === "check" ? "auto" : `${Math.max(1, field.h / page.height * 100)}%`;
    if (field.type === "check") element.style.aspectRatio = "1";
  }
}
